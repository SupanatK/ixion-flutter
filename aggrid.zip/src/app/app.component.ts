import { Component } from '@angular/core';
import { MockData } from './mock.data';
import {ColDef, ColGroupDef, ICellRendererParams} from 'ag-grid-community';
import 'ag-grid-enterprise';
import { INationalityRendererParam, NationalityRenderer } from './nationality.renderer';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  public rowData: any = MockData;

  public defaultColDefs: ColDef = {
    sortable: true,
    editable: true,
    filter: true
  }

  public columnTypes: {[key: string]: ColDef} = {
    resizableRow: {
      resizable: true
    }
  }

  public colDefs: ColDef[] | ColGroupDef[] = [
    {
      field: 'id',
      width: 100,
      headerName: ''
    },
    {
      field: 'firstname',
      type: 'resizableRow'
    },
    {
      field: 'lastname',
      type: 'resizableRow'
    },
    {
      field: 'age',
      type: 'number'
    },
    {
      field: 'nationality',
      headerName: 'Nationality',
      cellRendererParams: {
        abbreviationOnly: false
      } as ICellRendererParams & INationalityRendererParam,
      // cellRenderer: this.nationalityRenderer,
      cellRenderer: NationalityRenderer,
      type: 'resizableRow'
    }
  ]

  nationalityRenderer(params: ICellRendererParams & INationalityRendererParam) {
    if(params.abbreviationOnly){
      return `${params.value?.abbreviation}`
    }
    return `${params.value?.abbreviation} | ${params.value?.name}`
  }

  getRowId(params: any){
    return params.data.id;
  }
}
