import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";
import { ICellRendererParams } from "ag-grid-community";

export interface INationalityRendererParam{
  abbreviationOnly: boolean;
}

@Component({
  selector: 'app-nationality-renderer',
  template: `
    <div style="display: flex; flex-direction: row">
      <span style="width: 30px;">{{abbreviation}}</span>
      <span *ngIf="showName">- {{name}}</span>
    </div>
  `
})
export class NationalityRenderer implements ICellRendererAngularComp{
  public abbreviation: string = '';
  public name: string = '';
  public showName: boolean = true;

  agInit(params: ICellRendererParams & INationalityRendererParam){
    this.showName = !params.abbreviationOnly;
    this.abbreviation = params.data?.nationality?.abbreviation;
    this.name = params.data?.nationality?.name;
  }

  refresh(params: ICellRendererParams & INationalityRendererParam){
    this.showName = params.abbreviationOnly;
    this.abbreviation = params.data?.nationality?.abbreviation;
    this.name = params.data?.nationality?.name;

    return true;
  }
}