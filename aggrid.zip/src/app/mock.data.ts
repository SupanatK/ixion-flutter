export const MockData=[
  {
    id: 1,
    firstname: 'Penelope',
    lastname: 'Isidoros',
    nationality: {
      name: 'Ireland',
      abbreviation: 'IRL'
    },
    age: 29
  },
  {
    id: 2,
    firstname: 'Marlen',
    lastname: 'Hamm',
    nationality: {
      name: 'Sweden',
      abbreviation: 'SWE'
    },
    age: 32
  },
  {
    id: 3,
    firstname: 'Adelheid',
    lastname: 'Wessels',
    nationality: {
      name: 'France',
      abbreviation: 'FRA'
    },
    age: 30
  },
  {
    id: 4,
    firstname: 'Reginald',
    lastname: 'Neville',
    nationality: {
      name: 'Italy',
      abbreviation: 'ITA'
    },
    age: 27
  },
  {
    id: 5,
    firstname: 'Eugene',
    lastname: 'Brynn',
    nationality: {
      name: 'Greece',
      abbreviation: 'GRC'
    },
    age: 38
  }
]